import "./quantityPicker.css";
import React, { useState } from "react";

const QuantityPicker = () => {
  const [quantity, setQuantity] = useState(1);

  const increment = () => {
    
    console.log("Increment the value");
    setQuantity(quantity + 1);
  };
  const decrement = () => {
    console.log("Decrement the value");
    if (quantity > 1) setQuantity(quantity - 1);
  };

  return (
  
    <div className="quantityPicker">
      <button className="btn btn-sm btn-primary"
      onClick={decrement}>-</button>
      <label> {quantity} </label>
      <button className="btn btn-sm btn-primary" 
      onClick={increment}>+</button>
    </div>
  );
}

export default QuantityPicker;
