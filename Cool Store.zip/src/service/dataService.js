

var catalog = [
{
    _id: "1o2lks",
    title: "Sunglasses",
    price:"20.00",
    stock: "50",
    image:"",
    category:"Apperal",

},
{
    _id: "y123iuyoh",
    title: "jackets",
    price:"100.00",
    stock: "20",
    image:"",
    category:"Apperal",


},
];


class DataService {
    getCatalog() {
        //connect server
        //retrieve the catalog
        //return mock data

        return catalog;
    }


}

export default DataService;